(21) 2179-2007 - CREA

#Testes SIECC Homolog
#Testes Suporte
CC-325859-18113-13-502 #testes de CTC/CTC WD
CC-200345-18111-14-501 #testes de CTC/CTC WD

#Testes Gerais
CC-000000-80500-14-187 #teste de botão


#Consumível - Neoprene
01RA300D0008 - 125ml
01RA300D0006 - 1L

#=======================================================================================================
REV:

CC-000000-80500-12-061 '/13 /14' - (L01 CTEPROV31971103 - BX21031) para (L01 CTEPROV32170005 - BX21025)
CC-206140-80500-12-001 '/13 /14' - (L01 CTEPROV32169725 - BX21031) para (L01 CTEPROV20614004 - UL11028) - Só atualizar EPM


#Carlos
CC-000000-80500-12-027

MkDir ConferePasta

#=======================================================================================================

#PROG_NCR
#https://mybinder.org/v2/gh/jupyterlab/jupyterlab-demo/try.jupyter.org?urlpath=lab
#https://jupyter.org/try

CC-04D215-52BFM11-EX-12-004

Não foi identificado valor de torque para o parafuso M4 encontrado na MAT426-0557. Precisamos do valor de torque par o preenchimento das inspeções B11-19 (CTE01035420 e CTE01035421) para os AC43025 e AC43026, onde pede um valor de torque a ser ministrado em até o passos.

#Aperto a mão mais 1/4 de volta (SMB-200963)

#Torques para B11 e B06 SMB-200960 - f12 ou BDM-00019803 / por cmd 

'SMB-200949: MS02'
MN01 - F21
MN03 - F27 / F33
'SMB-200965: MS01'
MN10 - F35 / F51
MN45 - F39 / F52
MN50 - F43/ F53
MN4546 - F47


Para a fixação dos calços, caso uma classe ou M especificada na part list não condiza com as das SMB-200949 ou SMB-200965 poderá ser utilizada a SMB-200963 para aplicar os torques referentes, ou um torque específico deverá ser requerido via RIDA?



de um parafuso ou arruela não este


RD-04583 / 3329
32VI310D00094 and the washer 32VI410D00009 should not be used. 

2.1 Os elementos 01CA000D00501 e 01CA000D00508 foram fabricados no caderno CC-340582-50400-10-001, verificar disponibilidade


#CILINDROS ESPECIAIS

#As extremidades dos cilindros devem ser protegidas com plugues de vedação adequados a fim de evitar contaminação interna. Os plugues só devem ser removidos durante a conexão com os tubos. Os plugues deverão retornar quando os cilindros estiverem abertos (não conectados). Qualquer cilindro sem os plugues de vedação deve ser considerado contaminado e deve ser submetido a um exame boroscópico e novamente limpo se for encontrada alguma contaminação, conforme SMB-030510.

#MN01, a SMB-200949 só se aplica para parafusos de classe 12.9.

#MS02-1: SMB-200949 / SMB-002501
#MS01-2: SMB-200965 / SMB-002501
PHST = Packing, Handling, Storage, Transport																																										

'Placas de Manômetros'
'''
3.	O CMD 01CA000D00508 (SECURING BRACKET) é pago na LMA. Ver SMB-322139.
4.	Não são pagos os itens aplicados para a fabricação das placas de manômetro. 
5.	Nota específica a ser adicionada aos cadernos:
1.1.	Verificar a disponibilidade dos itens (CMD DA PLACA DE MANÔMETRO)  e 01CA000D00508 fabricados de acordo com CC-340582-50400-10-001.
'''
 
#Dotação SMB-00529
 
 
 
 
 

DT00101 - CTE000978557 - COS-SMB-200542
Identification inspection of electric pump DT00101 - SMB-000585

DT00201 - CTE00978559 - COS-SMB-200542
Identification inspection of electric pump DT00101 - SMB-000585

DT00301 - CTE00978560 - COS-SMB-200542
Identification inspection of electric pump DT00101 - SMB-000585


#ANALIZAR

cadernos com aterramento de cilindros
RD-07423

CC-000000-80500-13-022
2.1 Os elementos 01CA000D00501 e 01CA000D00508 foram fabricados no caderno CC-340582-50400-10-001, verificar disponibilidade. 




Cancelar - Eghon
CC-200710-30700-11-008
CC-200512-80500-12-004
CC-200516-80500-12-006


#SIECC AJUSTES INICIAIS PARA SUBSTITUIÇÃO DO CRC POR UM PROCESSO AUTÔNOMO
- Tempaltes (Entrar com Excel e gerar o PDF para relacionar na emissão para o Windchill)
- Relatório pro Windchill do que foi carregado (Incluído ou cancelado)
- Log de emissão de template. (Quantos emitidos, quantos substitídos, quem elaborou, etc)

#FUNCIONALIDADES TESTADAS E EM EXECUÇÃO NA PLATAFORMA DE TESTES:
- Emissão 0 de documentos junto com Templates para  o Windchill – OK = (O WD está recebendo os documentos perfeitamente com relações entre eles, porém os templates em pdf, precisam está no padrão esperado pelo sistema)
- Alterações de Templates – OK – (Tanto em Elaboração, como substituição após publicado é possível alterar Templates no Windchill)
- Relacionar CTC da LIT no Windchill (Devido a forma como esse assunto é tratado nas disciplinas de Seating|Pintura|Estrutura foi preciso relacionar os CTCs com os CTEs internamente no SIECC para então poder fazer isso para o Windchill)


#Comportamento do Windchill (Fora do Escopo)
- Recebe os arquivos e visiona internamente
- O SIECC não consegue deletar coisas do Windchill (O Processo é manual no Windchill - Assim será preciso gerar um relatório indicando as alterações a serem realizadas e enviar para o CEDOC executar as alterações)





#Dificuldades Gerais

- Preenchimento de templates de Calços
- Preenchimento de templates de B06
- Relacionar e quantificar CMDs para testes HH
- Torques em geral
- Inspeções de Anodos (CP1-1|CP1-2|CNC3|C24M|P02)
- Preenchimento MS01 e 02
- AIS em geral e (F07)






#CC Elaboração

CC-000000-80500-11-163
UA04301, UA04302, UA04303, UA04304 e UA04305


#Block por Caixa


CC-000000-30700-12-204
CC-000000-30700-13-204
CC-000000-30700-14-204

CC-000000-80500-13-042	0		Paulo
CC-000000-80500-14-042	0		Paulo


#----------------------------------------
#Rodrigo
verif #CC-000000-30700-11-015	B	#Atualizar os produtos EF12508B e EF12513B
verif #CC-000000-30700-11-029	A	#Revisar para cancelar CTEPROV L01 pois o L01 já foi pago em outro caderno e o o PROV utilizado percente a outro produto de mesmo CMX/revisar conforme o part list atual

verif #CC-000000-30700-11-057	A	#Excluir MT01 da LIT
verif #CC-000000-30700-11-116	B	#Excluir inspeção MT01  da LIT
verif #CC-200526-30700-11-016	B	#Deletar MT01 da LIT
verif #CC-200526-30700-11-002	C	#Deletar MT01 da LIT
verif #CC-319731-30700-11-008	A	#deletar CTE00947432 (MT01) da LIT
verif #CC-319724-30700-11-006	A	#Excluir MT01 da LIT
verif #CC-000000-30700-11-048	B	#Excluir CTE00923699 (MT01)

verif #CC-319712-30700-11-026	A	#Atualizar CCO-CABS, conforme PR-6114954
VERIF #CC-319712-30700-11-036	B	#Atualizar os CCO-CABs, conforme o PR-6114955 e o batch 34
VERIF #CC-000000-80500-11-008	C	#Atualizar CCO-CABS, conforme PR-6114956
VERIF #CC-000000-30700-11-038	A	#Atualizar os CC-cabs dos produtos P0148345 e P0149869
VERIF #CC-200526-30700-11-004	B	#Atualizar CCo-CABs, conforme batch 34 e PR-6627688
verif #CC-200544-30600-11-001	B	#Atualizar CCO-CABs, conforme batch 34 e PR-6114829
verif #CC-319731-16911-11-003	E	#Atualizar CCO-CAB
verif #CC-200551-30700-11-007	B	#Atualizar CCO-CABs, conforme batch 34 e PR-6114829
VERIF #CC-319712-30700-11-029	B	#Atualizar os CCO-CABs, conforme o PR-6114955 e o batch 34
verif #CC-000000-30700-11-002	A	#Atualizar CCO-CABS, conforme PR-6114956

verif #CC-000000-30700-11-119	A	#Atualizar LIT, conforme batch 34
verif #CC-319712-30700-11-028	B	#Atualizar LIT, conforme batch 34
verif #CC-200560-47319-11-001	B	#Atender o PR-6082146
VERIF #CC-200526-30700-11-009	A	#Deletar CTE00769921 (A03) - SMB-TDP-PR-5663046
SEM IMPÁCTO #CC-319724-30700-11-004	B	#CTE00934297 e CTE00934301
VERIF #CC-200526-30700-11-003	D	#Revisar conforme o part list atual
verif #CC-319712-30700-11-017	A	#Revisar para retirar o BE0200BM, BE0200BN, BE0200BP, BE0200BQ e BQ12919P| atualizar os CCO-CABs, conforme o PR-6114955 e o batch 34 / cancelar CTEPROV31971248 (L01) a pesagem foi feita no BQ12517P que tem o mesmo CMX do BQ12519P.
verif #CC-319726-30700-11-003	B	#Atualizar handbook do equipamento P0102566
verif #CC-319730-80500-11-006  A 	#Atendimento RD-07531

#----------------------------------------
#Tais
foi #CC-200718-80500-13-001	0		Tais
verif # 'CC-200718-80500-14-001'	0		Tais
#BDM-00057549
#----------------------------------------
#Madeira

foi #CC-000000-80500-13-039	0		Paulo
foi #CC-000000-80500-13-055	0		Paulo
foi #CC-000000-80500-13-062	0		Paulo = #RD-07647
foi #CC-000000-80500-13-071	0		Paulo

#3.9- O material para fixação dos STRAPs nos equipamentos FM00034, FM00043 e FM00203 foram pagos nos equipamentos FR00437, FR00438, FR00436, FR00435, FR00434 e FR00433 - Ver CC-000000-30700-13-206 (Anteriormente considerados como Dotação). Como serão necessários para fixação dos equipamentos FM00034, FM00043 e FM00203, os mesmos foram incluídos na LMA para que sejam instalados juntos com esses equipamentos. Aguardando resposta do RD-07672.



#BDM-00024962
#CMDs faltantes = SMB-001551
#14VM000D00037 | 14VM000D00039 | 29OU000D00583

Bt = 


block #CC-000000-80500-14-042	0		Paulo
verif #CC-000000-80500-14-039	0		Paulo
verif #CC-000000-80500-14-055	0		Paulo
verif #CC-000000-80500-14-062	0		Paulo
verif #CC-000000-80500-14-071	0		Paulo


#Não precisou revisar - CC-319724-30700-11-004 B 'CTE00934297 e CTE00934301'
verif #CC-200542-30600-11-001 A 'Atualizar o CCO SMB-EQUIPMENT-P0107201'


Foi #CC-000000-80500-11-163
verif #CC-000000-80500-12-184
verif #CC-000000-80500-13-184
verif #CC-000000-80500-14-184


#CC-200551-30700-13-004 - ok
#CC-200551-30700-14-004 - ok

#CC-319730-30700-13-001 - ok
#CC-319730-30700-14-001 - ok


HP22501 - CC-200535-30700-11-014
BE2720AC - CC-200535-30700-11-005




#CC-000000-80500-11-164 - ok

#CC-200526-30700-13-002 - ok
#CC-200526-30700-14-002 - ok


Maio

CC

#Paulo
'INTEGRAÇÃO DE PEÇAS MÓVEIS NA LIVRE CIRCULAÇÃO ÁREA INTERMEDIÁRIA (D215) - AC42059, AC42062, AC42063 E AC42064'
CC-339470-80500-12-002 - comentários = Atendido
CC-339470-80500-13-002 - Verif
CC-339470-80500-14-002 - Verif

#CC-319738-80500-13-005 - comentários - claudio
#CC-319738-80500-14-005 - Duplicar - claudio

CC-000000-80500-14-055 - comentários

CC-000000-80500-14-062 - comentários

CC-319720-80500-13-011 - comentários


CC-000000-80500-12-018
CC-000000-80500-12-060
CC-000000-80500-12-076
CC-200512-80500-12-003
CC-200512-80500-12-005
CC-200542-80500-12-042
CC-200718-80500-12-001
CC-208973-19110-11-001
CC-319693-80500-12-001
CC-319698-80500-12-007
CC-319719-80500-12-003
CC-319737-80500-12-003
CC-319760-80500-12-008
CC-339470-80500-12-002
CC-200538-80500-14-009 - liberado
CC-000000-80500-14-016
CC-200538-80500-14-012 - liberado (Não mexi)
CC-319734-80500-14-002 - foi
CC-200542-80500-14-010 - foi
CC-319760-80500-14-014 - foi
CC-200569-80500-14-005 - elaborado
CC-200569-80500-13-005 - revisr


CC-200569-80500-12-005
CC-200569-80500-13-005

ATUALIZADO NOTAS 2, 3.2, 4.2, 4.3 E ACRESCENTADA NOTA 3.3. ATUALIZADO DESENHOS DE INSTALAÇÃO E REVISADO ELEMENTOS DE FIXAÇÃO DA LMA.





Suba gradualmente de 0 a 240 para mbar
A válvula deve estar perfeitamente estanque (sem vazamento) até 240 a mbar

#W:\DIN\GD\DOC\01_COMPARTILHADO\CRC\01-CC\01 - Em Elaboração\CC-200535-30700-13-008_0

#Luis
'INTEGRAÇÃO DE EQUIPAMENTO NA VELA (D300) - BE2720AC E HP22501'
CC-200535-30700-12-008 - Foi
CC-200535-30700-13-008 - Foi
CC-200535-30700-14-008 - Foi

'INTEGRAÇÃO DE EQUIPAMENTOS NA PLATAFORMA SOBRE CALÇOS FLEXÍVEIS NO CORREDOR DAS ACOMODAÇÕES - AV (B320) - BE240AAE E EF02501'
CC-319759-30700-12-003 - CC-319759-80518-11-001 | CC-319759-30700-11-003 = Foi
CC-319759-30700-13-003 = x
CC-319759-30700-14-003 = x


'INTEGRAÇÃO DE EQUIPAMENTOS NAS ESTRUTURAS DAS ACOMODAÇÕES NO B310 - EF02504 E BF22703'
CC-319755-30700-12-002 - 	CC-319755-30700-11-002 | CC-319755-30700-11-006 = Foi
CC-319755-30700-13-002 = Foi
CC-319755-30700-14-002 = Foi


'INTEGRAÇÃO DOS ALERTAS SONOROS KLAXON 120 DB - HK02506, HK02504, HK02502, HK02505 E HK02503'
CC-000000-30700-13-044 - Verif
CC-000000-30700-14-044 = x

'TRANSMISSOR DE PRESSÃO 276BAR - BX10017P, DW12511P, DW12512P, BX10018P, BX10019P, DY12501P, DY12502P E BX10020P'
CC-000000-30700-13-029 - Foi
CC-000000-30700-14-029 = Foi


#Marquinho
CC-319228-30400-11-001 - Incluir CTE00860226 (E02 da LCM)
C-321703-80500-11-002 - Corrigir e revisar o CC-321703-80500-11-002 pois o produto do L01 foi preenchido com FC00524, que não tem relação nenhuma com esse caderno:
Aproveitar e Atender o rida RD-7587

PR-6082271
AP00021


32VI310D00093 
32VI410D00143






#Tais

CC-000000-30700-13-092 -FOI
CC-000000-30700-14-092 - FOI

CC-319731-30700-13-003 - FOI
CC-319731-30700-14-003 - FOI

#Tais
CC-319720-80500-13-003 - em verificação
CC-319720-80500-14-003


CC-000000-30700-13-087 - em verificação
CC-000000-30700-14-087
Adicionar CTEPROVs (CTEPROV31975870, CTEPROV31975871, CTEPROV31973728, CTEPROV31975225). Adicionar notas referenciando os RD-07921 e RD-07922.

ALTERADO DOCUMENTOS DE REFERÊNCIA E MODIFICADO ITENS NA LMA E LIT
ALTERADO NOTAS, ITENS DA LMA E ACRESCENTADO INSPEÇÕES MS01, MS01-1 E MS01-2 NA LIT


CC-319720-80500-12-004 - Em verificação
CC-319720-80500-13-004
CC-319720-80500-14-004
PR-6111931 
PR-6024992

fazer os templates -13- e -14-


CC-200549-30700-12-004



#-------------

CC-200716-80500-14-006 - paulo - verifica
CC-319719-80500-12-003 - coment
CC-000000-30700-14-106 - coment


32VI310D00010	4	HEXAGON REGULAR NUT M24 CL23 ZINC-FLAKE
32VI410D00079	4	SAFETY WASHER STEEL NL24-39,0-3,4 DELTA-PROTEKT

COATED SCREW H M24X80X54 CL8.8	329x
SCREWS H M16X90X38	Aperto a mão mais 1/4 de volta
SCREW H M24X150X60 CL12.9 DELTA SEAL	431 - 923














#====================================================
#Junho 2020
#Luis
'INTEGRAÇÃO DE EQUIPAMENTOS NA ESTAÇÃO RÁDIO (B351) - HJ02527 E HG02561'
CC-200549-30700-12-004 - feito - ok
CC-200549-30700-13-004 - feito - aguardando...
CC-200549-30700-14-004 - feito - aguardando...

'INTEGRAÇÃO DOS SOQUETES BRANCOS 250V 20A'
CC-000000-30700-13-100 - feito - ok
CC-000000-30700-14-100 - feito - ok

'INTEGRAÇÃO DAS TOMADAS 2 ENTRADAS'
CC-000000-30700-13-144 - feito - ok
CC-000000-30700-14-144 - feito - ok
CC-000000-30700-12-144 ------- revisar - ok

3.2. Quantidade de elementos de fixação modificados para o BT22504, conforme PR-5559067 e SBH.4C20.SMD.003952.
ATUALIZADA LMA CONFORME BATCH 35 E MODIFICADO ELEMENTOS DO BT22504 CONFORME PR-5559067.

'INTEGRAÇÃO DE EQUIPAMENTOS NO COMPARTIMENTO DE VENTILAÇÃO (B202) -FH12601Q, FH12501T, FH02602, FH02601, FH02901 E FH00501'
CC-319738-30700-13-006 - feito - ok
CC-319738-30700-14-006 - feito - ok

'INTEGRAÇÃO DOS DETECTORES DE NÍVEL DO TANQUE DE DRENAGEM - DA12517N, DA12518N, BQ12526N E BQ12527N'
CC-000000-30700-13-198 - feito - ok
CC-000000-30700-14-198 - feito - ok


	alterar quantidades de elementos de fixação do BT22504 - PR-5559067



publicados
CC-319755-30700-12-002
CC-319755-30700-13-002
CC-319755-30700-14-002




ver co Flavio
CC-319757-80500-11-001









#==========================================
#Meta Julho
#Luis
'CONEXÃO ELÉTRICA DOS ACESSÓRIOS ELÉTRICOS DIVERSOS INSTALADOS NA TUBULAÇÃO - EM00013F, EJ11050R, EM00013O, EM00007O, EM00007F E EG12580R'
CC-000000-30600-12-080 = ok
CC-000000-30600-13-080 = ok
CC-000000-30600-14-080 = ok

'CONEXÃO ELÉTRICA DOS ACESSÓRIOS ELÉTRICOS DIVERSOS INSTALADOS EM HVAC E EM PEÇAS DE PASSAGEM - FH00010, AB36001, FH00011 E FH00015'
CC-000000-30600-12-081 = ok - RD-07952 - CC-321710-80500-12-009
CC-000000-30600-13-081 = ok
CC-000000-30600-14-081 = ok

'CONEXÕES ELÉTRICAS DE EQUIPAMENTOS MONTADOS NA TUBULAÇÃO NO POÇO A BORESTE NO C200 - DS14121P, DS14221P, DS14321P, KT00417 E KT18177P'
CC-327472-30600-12-001 = ok
CC-327472-30600-13-001 = ok
CC-327472-30600-14-001 = ok

'INTEGRAÇÃO DOS QUADROS DE DISTRIBUIÇÃO DE ILUMINAÇÃO SECUNDÁRIA - BE06400, BE06100, BE07100 E BE07200'
CC-000000-30700-13-125 = ok
CC-000000-30700-14-125 = ok

'INTEGRAÇÃO DE EQUIPAMENTOS NO COMPARTIMENTO DO COMANDO (B350) EXCETO NA PLATAFORMA SOBRE CALÇOS FLEXÍVEIS - RM12511M, RM12521M e RM12512M'
CC-319760-30700-12-016 = veirif
'Adicionar (D95_08, D95_12 e D95_40) conforme batch atual'


'INTEGRAÇÃO DE EQUIPAMENTOS NO COMPARTIMENTO DO EJETOR DE LIXO (B201) - FP00100'
CC-319737-80500-12-005 = veirif
'Atender o rida RD-07633 E 7632|Adicionar inspeção E01 FP12500M'
'CTE00943198 will be deleted from COS-SMB-319737.CTE00943198'



#Mel
'INTEGRAÇÃO DAS CAIXAS DE JUNÇÃO DO SUBSISTEMA BE'
CC-000000-30700-12-124 - CC-000000-30700-11-042 - CC-319712-30700-11-015
CC-000000-30700-13-124
CC-000000-30700-14-124

CTE00792252, CTE00797011, CTE00799688 e CTE00847316


















CC-000000-30700-12-058
CC-319731-30700-12-004
CTE00953516
CTE00799380
53B-BF02502
53B-BF02505



CC-000000-80500-12-005 - rev
CC-000000-80500-13-005 - ?
CC-000000-80500-14-005 - ?

CC-000000-80500-12-006 - não precisam
CC-000000-80500-12-008 - não precisam
CC-200542-80500-12-009 - não precisam

CC-000000-30700-12-102 - rev
CC-000000-30700-13-102 - ?
CC-000000-30700-14-102 - ?

CC-000000-30700-12-106 - não precisam

CC-000000-80500-12-181 - REV

CC-319752-80500-12-002 - REV
CC-319752-80500-13-002 - ?

CC-200716-30700-12-005 - xxx






CC-319730-30700-12-001 - F07
CC-319731-30700-12-001 - F07



Alterar Template MS
CC-200716-30700-12-007 = ok




#Revisar cadernos de Cabos
#RD-07707 - Esperar rida
PR-6080672
SMB-TDP-PR-6027824
SMB-TDP-PR-6027828
PR-6028086

TAF-TA-2018-0918

RD-6802



corrigir rota EQ22502R (E02 do MAZ)

CC-000000-30400-12-001
CC-000000-30400-13-001
CC-000000-30400-14-001










#-------------------------------




'DCNS, according to part list for COS-SMB-319724_C there is duplicity of fixation items of equipment EL00106 (P0119819) on seating EL00106C (P4155189). It is listed in part list the following items:'
32VI310D00055 (COATED NUT H M4 CL8)
32VI410D00074 (STEEL WASHER N-L ND8 DELTA-PROTEKT)
32VI310D00094 (COATED NUT HFR PLASTIC SLEEVE M8 CL8)
32VI410D00009 (COATED PLAIN WASHER M ND8 40CRMOV4-6)
'If we use 32VI310D00094 and 32VI410D00009 as described in SMB-322139_B (F05), where should be used the other two (32VI310D00055 and 32VI410D00074)? Please clarify.'

HFR M8 CL10
21 ±10% (RD-03329)
HFR M8 CL8
21 ±10% (RD-03329)
HM6 CL8.8
12
HM5 CL12.9
7.7


RD-04583


RD-04583 / 3329
32VI310D00094 and the washer 32VI410D00009 should not be used.


SMB-322139


Conforme resposta do RD-04583 os eleentos de fixação 32VI310D00094 e 32VI410D00009 não serão utilizados. A barra roscada 32VI210D00816 já é fornecida com a placa

Não foi identificadoporcas e arruelas para fixação dos calços flexíveis DN00131S. O DY01664S e outros equipamentos 01CA000D00500, utilizam M8 CL12 . Favor confirmar

The DN00131S nuts and washers for fixing the flexible shims were not identified. The DY01664S and other equipment 01CA000D00500, use M8 CL12. Please confirm

W:\DIN\GD\DOC\01_COMPARTILHADO\CRC\01-CC\03 - Aprovados\CC-000000-80500-13-022_0\12 - Templates de Inspeções\SUBSTITUIÇÃO DE TEMPLATE








#===============================================================================================================
W:\DIN\GD\DOC\01_COMPARTILHADO\CRC\01-CC\01 - Em Elaboração\CC-200542-30600-11-001_A\12 - Templates de Inspeções



INSTALAÇÃO DOS EQUIPAMENTOS
1. DESENHOS DE REFERÊNCIA:
1.1 Para instalação dos equipamentos ver documentos de referência na capa do caderno.
2. MONTAGEM A BORDO:
2.1 É estritamente proibido utilizar lubrificantes para montagem dos parafusos e porcas, esses componentes devem ser montados a seco.
2.2 Os equipamentos com CMD 11BR000D00015 possuem CMDs decompostos (11CI117D00004, 11BR000D00046 e 11AC100D00255), deverão se pagos individualmente conforme listado na LMA.
2.3 Interruptor bipolar com CMD conforme caixa.
2.4 Conforme SBH.2B10.SMD.006751 o equipamento 53V-BE00118 será colado no suporte. Elemento de fixação descrito na IT-319467-18111-12-001.
2.5 Conrfome RD-04604 os equipamentos BE00120, BE00121 deverão possuir um "BIPOLAR BREAKER 10A" - CMD: 11AP600D00236, conforme SMB-000750 CONEXÕES DE CABOS A EQUIPAMENTOS ELÉTRICO
3. DESENHOS DE REFERÊNCIA:
3.1 Para conexão dos equipamentos ver documentos de referência na capa do caderno.
3.2 Os conectores para os cabos elétricos são fornecidos em conjunto com os equipamentos, portanto o material está associado aos produtos dos equipamentos.
4. NOTAS:
4.1 A inspeção QA01 (CTE00880495, CTE00920595, CTE00760085, CTE00887335, CTE00776618, CTE00797011 e CTE00799688), só será realizada após a montagem de todos os equipamentos desse COS.
4.2 As inspeções referente a medições nos cabos irão aparecer em dois cadernos, mas a mesma só será realizada após a conexão das duas extremidades nos equipamentos, desta forma considerar apenas um Template.
4.3 O check list no Anexo A deverá ser utilizado e preenchido devidamente pelo eletricista envolvido na execução do trabalho para cada equipamento e deverá ser repassado para o controle da qualidade executar a inspeção E01 (SMB-325109 - F115).
4.4 Os equipamento listados na LMA, segundo manual CCO-CAB, não precisam de malha de aterramento.
4.5 Os CTEs Provisórios, foram criados em atendimento a TAF-TA-2015-0588.

4.6 De acordo com orientação do "TA" durante "OJT" referente a conexão elétrica, cabos de rede PROFBUS, deverá ser considerado as seguintes posições de entrada no conector "AXIAL 6GK1500-0EA02". O conector possui 4 (Quatro) bornes para ligação dos cabos, caso a ligação a ser realizada no mesmo seja com apenas dois cabos, deverá sempre ser ligada aos 2 (Dois) bornes da esquerda do conector.




2.5 Os equipamentos BQ22505 e BQ22509 foi alterado os furos para fixação e substituido o material de fixação conforme resposta do rida RD-04803
2.6 O parafuso para fixação veio no part list do equipamento de acordo com o BDM-00073764 e entregue a produção sem a verificação da caixa .
2.7 Em função do tipo de fixação não é previsto torque para os elementos de fixação dos equiapmentos BQ22505 e BQ22509 (aplicar aperto a mão mas 1/4 de volta).






#-----------------------------------------------------------------


#Aperto a mão mais 1/4 de volta (SMB-200963)


 4.3 Os Handbooks serão utilizados conforme SMB-TDP-PR-6114956:
 - SMB-EQUIPMENT-P0135967 - ANEXO-0000198801
 - SMB-EQUIPMENT-P0135337 - ANEXO-0000198800
 - SMB-EQUIPMENT-P0136196 - ANEXO-0000198805
 - SMB-EQUIPMENT-P0136227 - ANEXO-0000198799
 
 
 
 
 
INSTALAÇÃO DOS EQUIPAMENTOS
1- PRÉ-REQUISITOS PARA INSTALAÇÃO:
1.1- Antes da instalação deve ser verificado a presença de todos os principais elementos:
- Windlass (Incluindo stopper);
- Painel de Controle Hidráulico;
- Painel de Controle Elétrico.
1.2- Para fabricação de shim dos equipamentos (53B-EX00040), ver SBH.4D10.SMD.003549_D
(F32).
1.3- Verificar se o equipamento 53B-EX00040 esteve armazenado em condições ideais de temperatura, umidade, luz e radiação conforme BDM-00057549 (F5).
1.4- Verificar se o equipamento 53B-EX00040 passou pelas manutenções necessárias conforme BDM-00057549 (F05-F06).
2. MONTAGEM NA SALA LIMPA:
2.1- Os procedimentos para montagem e inspeção M09 para 53B-EX00040_H , estão descritos no documento MAT211-0224(F06-F09) e SMB-208037.
3. INSTALAÇÃO A BORDO:
3.1- É estritamente proibido utilizar lubrificantes para montagem dos parafusos e porcas, esses componentes devem ser montados a seco. (EXCETO QUANDO INFORMADO).
3.2- O 53B-EX00040 é entregue com olhais M10 para movimentação e com plugues M10 com selos para substituir os olhais uma vez que o 53B EX00040 esteja pronto para uso. Este plugues evitam a oxidação e a corrosão da rosca. Slings e manilha não estão incluídos no equipamento,
conforme BDM-00057549 (F22).
3.3- O equipamento possui dois pontos de conexões hidráulicas: o controle hidráulico e as placas de conexão. Para o ajuste hidráulico, ver BDM-00057549 (F07-F10).
3.4- O sistema só poderá operar quando o painel de controle estiver conectado,
ver BDM-00057549 (F07-F10).
3.5- Para torque no painel de controle, ver tabela no BDM-00057549 (F10).
3.6- Se a pintura for danificada durante a desembalagem ou instalação a bordo, esta deve ser retocada conforme SMB-002345.
CONEXÃO DOS EQUIPAMENTOS
4. CONEXÃO:
4.1 Os conectores para os cabos elétricos são fornecidos em conjunto com os equipamentos,
portanto o material está associado aos produtos dos equipamentos.
5 NOTAS:
5.1 A inspeção QA01, inspeção final de trabalho (CTE00770235), só será realizada após a montagem de todos os equipamentos desse COS.
5.2- O check list no Anexo A deverá ser utilizado e preenchido devidamente pelo eletricista envolvido na execução do trabalho para cada equipamento e deverá ser repassado para o controle da qualidade executar a inspeção E01 (SMB-325109 - F115).




1. PRÉ-REQUISITOS PARA INSTALAÇÃO


. Durante a montagem de equipamento sujeito à rastreabilidade, é necessário verificar a
sua referência para atribuí-la à sua marca funcional, em conformidade com os documentos
SMB-200052 e SMB-200945. A zona de marcação deve permanecer o mais acessível possível
após montagem.












#Conexão

1. DESENHOS DE REFERÊNCIA:
1.1 Para conexão dos equipamentos ver documentos de referência na capa do caderno.
1.2 Os conectores para os cabos elétricos são fornecidos em conjunto com os equipamentos, portanto o material está associado aos produtos dos equipamentos.
2. MONTAGEM A BORDO:
2.1 Os equipamentos (EM00013F, EM00013O, EM00007F, EM00007O, EJ11050R, EG12580R) serão instalados pela tubulação.


1. DESENHOS DE REFERÊNCIA:
1.1 Para instalação dos equipamentos ver documentos de referência na capa do caderno.
1.2 Os conectores para os cabos elétricos são fornecidos em conjunto com os equipamentos, portanto o material está associado aos produtos dos equipamentos.
2. MONTAGEM A BORDO:
2.1 Os equipamentos (FH00010, AB36001, FH00011 E FH00015) serão instalados pela tubulação.
3. NOTAS:
3.1 A inspeção QA01, inspeção final de trabalho, só será realizada após a montagem e conexão de todos os equipamentos de cada COS.
3.2 As inspeções referente a medições nos cabos poderão aparecer em dois cadernos, mas a mesma só será realizada após a conexão das duas extremidades nos equipamentos, desta forma será gerado apenas um template.
3.3 O check list no Anexo A deverá ser utilizado e preenchido devidamente pelo eletricista envolvido na execução do trabalho para cada equipamento e deverá ser repassado para o controle da qualidade executar a inspeção E01 (SMB-325109 - F127).
3.4 A inspeção L01 para os equipamentos foram elaboradas e executadas no caderno de instalação.



#============================
Testes de Cadernos Novo SIECC

CC-000000-30700-11-710

Boa tarde Eduardo,

Fiz alguns testes com o eghon hoje e tivemos as seguintes impressões:





Relatório dos Testes:

Fiz alguns testes com o Eghon hoje sobre a carga dos Templates no Windcchill. IMZ está 100% aceitando as cargas. Suporte, Estrutura, também aparentam está ok. Apenas pintura que apresenta um problema que está sendo analisado. Acredito que o mesmo problema de pintura pode acontecer nos outros, pois é algo bem genérico. Mas acho que resolvendo isso, já se resolver todos os outros possíveis casos.

Uma vez finalizado isso, ainda temos alguns desafios pela frente, como Revisão e Substituição de templates. O Eghon está estudando junto ao desenvolvedor da API, que integra SIECC e Windchill, uma solução para isso.  Hoje quando o template já existe no Windchill o SIECC n consegue substitui-lo automático e precisará rever isso.

Outra coisa é, Seting/Estrutura/Pintura geram tempaltes pelo SISEPC e o nome lá do arquivo vem todo diferente. Eles precisaram renomear esses arquivos para que tenham o mesmo nome que tem na LIT deles pra que a carga seja reconhecida. Isso hoje quem faz é CRC, saindo eles, essa tarefa fica na mão de cada elaborador ou quem fará?

O SIECC não vai conseguir fazer isso porque ele não tem essa aplicabilidade, nem o EPM. O EPM gera os templates porque ele gera o arquivo completo, se tivesse que fazer só essa alteração de nome, separadamente, também seria um problema. Mas vou avaliar com Flavio a aplicabilidade disso também. Não sendo possível, só resta criar macros (o que tenho medo de propor pq sei que vai sobrar pra mim. Rsrsrs)


















