
KT00121S = RD-07698




#questionamento de cabos RD-07780 = RD-07754

os cabos
RD-07576
RD-07754

BIGRAMA	IM	CTE	PRODUTO	TYPE
UA	UA65593D	CTE01031055	P0145033	E09
UA	UA63334D	CTE01031056	P0144965	E09
UA	UA65594D	CTE01031058	P0145034	E09
UA	UA63333D	CTE01031059	P0144966	E09

#REVISAR:
P0153873 EG62782I EG02503 G24772 11LS222D00016 = CC-319712-30700-12-032 / CC-345125-30700-12-001 - CTEPROVCAB-EF-EZ14
P0153871 EG62780I EG02503 EG24770 11LS222D00016 = CC-319712-30700-12-032 / CC-345125-30700-12-001 - CTEPROVCAB-EF-EZ13



#Eghon - mudar Status pra Pulicado e voltar pra revisão 0
CC-200716-30700-12-008 - mudar Status pra Pulicado e voltar pra revisão 0
CC-200532-30700-12-003 - mudar Status pra Pulicado e voltar pra revisão 0
CC-200526-30700-12-021 - mudar Status pra Pulicado e voltar pra revisão 0


Ajustes:

CC-200526-30700-12-022
Atualziar CCo-CAB








#ver com Claudio
CC-200763-80500-12-005

P0119979 - 






#Caderno Rodrigo Elétrica
CC-321715-30400-11-001






#=============================================
#CTEs justifica Felipe
COS-SMB-200566

CTEPROV20056604
CTEPROV20056606


#----------------------------------------------------
#Cadernos Correção
FA20155	P0147144	CC-200516-80500-11-010
FA20156	P0147145	CC-200516-80500-11-010
EQ00511	P0139826	CC-319718-80500-11-008
AL00062	P0158215	CC-319750-80500-11-018

Bloqueado com o RD-07808


Os equipamentos AL00062, FA20155 e FA20156 não foram identificados na maket 3D, impossibilitando definir o posicionamento dos mesmos no SBR. Favor esclarecer
The equipments AL00062, FA20155, FA20156 and EQ00511 were not identified on 3D, making it impossible to define or position them in the SBR. Please clarify

RD-07808




#Análise Emial Marquinho
-----------------------------------------------<<<<<<<<<<<<<<<<<<<<<
CC-319739-80500-11-005
erro de status
Vista do SIECC = publicado - http://epm.icnavais.net/%40VW_ICN_SIECC_LIT_INT_TEEWE
META = (Em Elaboracao) - http://epm.icnavais.net/%40INT_DELNT_CRTL_META
Produto X CADERNO = (Em Elaboracao) - http://epm.icnavais.net/%40INT_DELNT_CRTL_META

CC-319750-80500-11-017 - pareciso com o caso de cima, Publicado no SIECC, mas ta vindo sem status no produto x caderno e metaStatus


#Ver com Flavio

CTEs não retornados no MAPA
'CTE01031055',
'CTE01031056',
'CTE01031058',
'CTE01031059'

CTE00806581
CTE00806589
CTE00976087
CTE00976101

tirar o _X001 da jogada

colocar int-caixa pra todos

Arrumar planilha do Guilherme


CTE01037795
CTE01037796
CTE01053216
CTE01052275


#--------------------------------------

Inconsistência:

EF02510 - 	CC-319730-30700-12-003 - rev - A mas n tem no SIECC

Status
CC-319712-80500-11-020 - Existe no SIECC, mas n vem na Vista (talvez poroblema do Eghon)
CC-319738-80500-13-004 - status diferentes









#marquinho RAI
CC-000000-30700-12-152
RAI-SBR2-01861-CCO
CC-000000-30700-12-141
RAI-SBR2-01529-CAB
CC-000000-30700-12-125
RAI-SBR2-01524-CAB





CC-200551-80510-11-002
CTE01046935

CC-319720-30600-11-001
CTE00961358



CTE01032155 ta IR, ta vindo no MAPA mas o SBR2 não ta preenchido, deveria ser :

CC-200542-30700-12-026 - CTE00769497






Nome: 
Animal: 
Objeto: 
Cidade: 
Filme: 
Personagem: 
Cor: 
Carro: 





(RD-07754


#=============================================

#Cable Rev
RD-06802



#Resposta Rida RD-07576:
UA63333D, UA63334D, UA65593D, UA65594D and EF62517R - E09 DA62554R
KD68572D - SMB-204795_E - "E07 and E23" 
UP62600I - E11 - SMB-051204 will update


(RD-07754)
Ainda relacionado ao RD-07576, identificamos que os cabos UA63333D, UA63334D, UA65593D e UA65594D, não estão relacionados na SMB-330521. O cabo EF62517R consta como deletado na SMB-330521. Favor esclarecer

Still related to the RD-07576, we found that the cables UA63333D, UA63334D, UA65593D and UA65594D, are not related in the SMB-330521 and the EF62517R cable is listed as deleted. Please clarify




marcus egeprom
200718-80500-12-001


#===============================


RD-07572
According to RD-03490 the Part List Needs to be updated, because DS00101 belong to the LPR-DS00100. Please verify and update.

RIDA Answered
Even though they DS00100 and DS00101 are integrated, they do not belong to the same product lot. No part list impact.


RD-03490
Equipment DS00101 appears in part list as a LPR (product lot) with CMX 18SC273F00008, but it seems to be part of CMX 12GC000D00003 (DS00100) according to BDM-00036728. Please clarify if DS00101 is delivered assembled with DS00100 or separated.

RIDA Answered
According to COS-SMB-200712 part list, CMx 18SC273F00008 includes items DS14111 and DS14101, wich are part of DS00101 (18SC273D00020). All these RFs are included in DS00100 (12GC000D00003). All of these items are delivered with DS00100.










Meu amigo eu queria te fazer uma pergunta, eu to pensando em mudar lá pro meio do Ano. E queria saber de você se vc teria a rota do ônibus da barra, se não me engano linha-1. Eu queria saber se tem vaga nessa rota e se vc teria o roteiro do ônibus. Pra eu tentar arrumar alguma coisa mais próximo da rota possível.

Você teria isso?


praça do Pomar
















SMB-TDP-PR-6026628
SMB-TDP-PR-6026129
SMB-TDP-PR-5494172
SMB-TDP-PR-5572840
SMB-TDP-PR-5653648
SMB-TDP-PR-5802292
SMB-TDP-PR-5915029





#-----------------------------
BS22500	CTE00974547	P0153915	LINE SPLICES 1 X 95 MM² MZH	COS-SMB-345124	E12	 	 	 	falta cte no portal
BS22501	CTE00974514	P0153918	LINE SPLICES 1 X 95 MM² MZH	COS-SMB-345124	E12	 	 	 	falta cte no portal
BS22502	CTE00974541	P0155338	LINE SPLICES 1 X 95 MM² MZH	COS-SMB-345124	E12	 	 	 	falta cte no portal
BS22503	CTE00974536	P0155339	LINE SPLICES 1 X 95 MM² MZH	COS-SMB-345124	E12	 	 	 	falta cte no portal



'CTE00974547',
'CTE00974514',
'CTE00974541',
'CTE00974536'











































#Algumas aplicações em VBA

'Sub nome()'
	- Sub = Comando para abrir uma função
	- nome = Nome da função
	
'end sub' = Fecha a função
	
'Windows("arq.xlsx").Activate'
	- Windows() = Chama o arquivo que deseja abrir
	- arq.xlsx = Nome do arquivo (Nome do arquivo fica sempre entre "" porque se trata de uma string)
	- .Activate = Abre o arquivo

'Sheets("aba").Select'
	- Sheets() = Chama a aba que deseja abrir
	- aba = Nome da aba (Nome da aba fica sempre entre "" porque se trata de uma string)
	- .Select = Seleciona a aba
    
'Range("A1").Select'
    - Range() = Função de delimita a célula que se pretende selecionar
	- A1 = Coluna e linha que corresponde a célula desejada ('A' = Coluna | '1' = Linha)
	- .Select = Seleciona a célula
	
'ActiveCell.Offset(1, 0).Select'
    - ActiveCell = Ativa a função para seleção de cálula
	- Offset() = Determinar qual o range entre celulas será delimitado
	- 1,0 = Posicionamento de célula (1 = posição da linha | 0 = posição da coluna >> Tudo em relação a posição atual da célula pre-selecionada, ou seja, não importa a célua que você está, conforme aumente essa numeração, mais posições, tanto na linha como coluna, serão saltadas.)
	- .Select = Seleciona a célula

	
#Declaração de variáveis

'variáveis'
	- Variáveis são espaços reservados na memória (RAN) do programa para se guardar informações. (Ou seja na memória RAM as informações guardadas nessas variáveis após acaba a intrução do programa ela se perde. Os valores armazenados nessa memória só poderão ser acessados durante o programa. Acabando a instrução ou reeniciando a planilha, esses dados se perdem)


	
Prezados,

o EPM está apresentando uma instabilidade na LIT que vem do SIECC. Como todo sistema está interligado, as tabelas de gerar caderno ou a prórpia LIT de carga que é baixada no EPM, retorna com erro e não está sendo baixada. Devido a outros problemas no sistema ICN, ainda não foi possível corrigir o erro. Assim, que precisar de uma LIT pra clocar no caderno, me passem o número do caderno que eu consigo extrair diretamente do banco de dados do EPM pra adiantar pra vocês.

Qualquer dúvida estou a disposição.





Já está sendo 



	
	
	
	



