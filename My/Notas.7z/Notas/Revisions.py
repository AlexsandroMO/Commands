#======================
#TAIS

CC-319720-80500-12-004 - Em verificação
CC-319720-80500-13-004
CC-319720-80500-14-004


#==============================
#MEL
CC-000000-80500-12-018 - foi

#-----------------------------------------------
CC-000000-80500-12-060

CANCELADA INSPEÇÃO M02 CONFORME RD-07814, INCLUÍDAS INSPEÇÕES B06. ALTERADO QUANTITATIVOS MATERIAIS NA LMA
Atender o rida 07814| inclusão de material na LM e inspeção B06-1 destinadas aos equipamentos EQ00411 e EQ00412, Utilizar como referência o CC-000000-80500-13-060 | Atualizar LMA conforme PR-6028254 [EQ00411]
#-----------------------------------------------
CC-000000-80500-12-076

'revisar conforme ridas 5948=ok, 6182=ok e 6187; atender o PR-6028091|Atender PR-570711 (P0154463)/Atualizar CC com desenhos de posicionamento de cabos nas moving parts. PR-5915042 - AC42039 - SBH.2D30.IMZ.006924'

ATUALIZADOS DOCUMETNOS DE REFERÊNCIA

ATUALIZADAS NOTAS 3.5, 4.2 A 4.4. CANCELADA NOTA 4.4 e 4.5. ATUALIZADA LMA, SUBSTITUIDO CTE L01
#-----------------------------------------------
CC-200512-80500-12-005

ATUALIZADOS DOCUMETNOS DE REFERÊNCIA
MODIFICADAS NOTA 1.1, 2.3, 2.4, 43 E 4.4. ADICIONADAS NOTAS 1.2 E 1.3, 2.5, 2.6, 4.3, 4.4. CANCELADA NOTA 4.5 E 4.6. MODIFICADO DESENHOS DE INSTALAÇÃO E INTEMNA LMA CONFORME PR-5953224 E PR-6082277.

morreu - não tem na IR
4.3- OS CTES (CTC00973535, CTE00973536 e CTE00973537) para FC00030S e (CTC00973541, CTE00973542 e CTE00973543) para FC00031S, não se aplicam a esses equipamentos, conforme resposta ao RD-06140.

#------------------------------------------------
CC-000000-30700-14-087 - ok
#------------------------------------------------
CC-000000-30700-13-092

ATUALIZADA NOTA 5.2, DESENHOS DE INSTALAÇÃO E CORREÇÃO DE TORQUES
#-----------------------------------------------------

CC-319698-80500-12-007
#-----------------------------------------------------

#-----------------------------------------------------

CC-000000-80500-13-060
CC-000000-80500-13-076
CC-000000-30700-14-092

CC-200512-80500-13-005
CC-200512-80500-14-005

CC-319698-80500-13-007
CC-319698-80500-14-007



FH00310, FH00320 e FH00410 já vieram montados no pai.



CC-200572-42500-11-001
na análise de rev_COS a rev do COS do CC ta errada. Dentro da capa já ta a versão certa. (por isso o SIECC retorno diferente)


